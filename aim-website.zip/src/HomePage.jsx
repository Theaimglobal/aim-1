import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen text-[#2B2B2B] font-sans bg-[url('/background-texture.jpg')] bg-cover bg-no-repeat bg-center">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-[#fefefe] bg-opacity-95 backdrop-blur-sm">
        <h1 className="text-xl font-bold tracking-wide text-[#1A1A1A]">AIM</h1>
        <nav className="space-x-6 text-sm text-gray-600">
          <a href="#services" className="hover:text-[#007AFF] transition">Services</a>
          <a href="#about" className="hover:text-[#007AFF] transition">About</a>
          <a href="#contact" className="hover:text-[#007AFF] transition">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="flex flex-col items-center justify-center text-center px-4 py-24 bg-white bg-opacity-90">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-6xl font-semibold max-w-3xl text-[#1A1A1A]"
        >
          Strategy. Clarity. Growth.
        </motion.h2>
        <p className="text-gray-700 mt-6 max-w-xl text-lg">
          AIM is a consultancy and marketing agency that transforms brands and businesses with a clear, data-driven approach.
        </p>
        <Button className="mt-8 px-6 py-3 text-white bg-[#007AFF] hover:bg-[#005FCC] rounded-full text-sm">
          Get Started <ArrowRight className="ml-2 w-4 h-4" />
        </Button>
      </section>

      {/* Services Section */}
      <section id="services" className="px-6 py-20 bg-[#F9FAFB]">
        <div className="max-w-5xl mx-auto text-center">
          <h3 className="text-2xl font-medium mb-12 text-[#1A1A1A]">What We Do</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { title: "Brand Strategy", desc: "Defining and positioning your brand to stand out." },
              { title: "Digital Marketing", desc: "Results-focused campaigns across platforms." },
              { title: "Consulting", desc: "Tailored insights to drive business decisions." }
            ].map((service, idx) => (
              <Card key={idx} className="p-6 shadow-sm hover:shadow-md transition bg-white border border-gray-100 rounded-xl">
                <CardContent>
                  <h4 className="font-semibold text-lg mb-2 text-[#1A1A1A]">{service.title}</h4>
                  <p className="text-sm text-gray-600">{service.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="px-6 py-20 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl font-medium mb-6 text-[#1A1A1A]">Who We Are</h3>
          <p className="text-gray-700 text-lg">
            Based on a foundation of expertise and innovation, AIM empowers companies to grow smarter through marketing and consulting services. We're partners in your evolution.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="px-6 py-20 bg-[#F9FAFB]">
        <div className="max-w-xl mx-auto text-center">
          <h3 className="text-2xl font-medium mb-6 text-[#1A1A1A]">Get in Touch</h3>
          <p className="text-gray-700 mb-6">
            Ready to elevate your business? Reach out to our team to start the conversation.
          </p>
          <Button className="px-6 py-3 bg-[#007AFF] text-white hover:bg-[#005FCC] rounded-full text-sm">
            Contact Us
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-8 border-t border-gray-200 text-sm text-center text-gray-500 bg-white">
        © {new Date().getFullYear()} AIM. All rights reserved.
      </footer>
    </div>
  );
}
